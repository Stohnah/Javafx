package com.example.mokholutsoane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.io.IOException;

public class Login {

    @FXML
    private Button btnLogin;

    @FXML
    private Button btnsignup;

    @FXML
    private Label lblPassword;

    @FXML
    private Label lblUsername;

    @FXML
    private TextField txtUsername;

    @FXML
    private TextField txtpassword;

    @FXML
    void onLogin(ActionEvent event) throws IOException
    {


        Alert A= new Alert(Alert.AlertType.ERROR);
        String url = "jdbc:mysql://localhost:3306/university";
        String user = "root";
        String pass = "123456";
        String sql = "select * from users where user=? and pass=?";
        try {
            Connection conn = DriverManager.getConnection(url,user,pass);
            PreparedStatement stm = conn.prepareStatement(sql);
            stm.setString(1,this.txtUsername.getText());
            stm.setString(2,this.txtpassword.getText());

            ResultSet r = stm.executeQuery();
            if(r.next()){

                Stage Mystage = new Stage();
                String title = "student registration form";
                HelloApplication.nav( Mystage,"Registration.fxml",title.toUpperCase(),600,400 );
            }
            else {System.out.println("login failed");}
            stm.close();
        }
        catch (SQLException e){
            //print message
            System.out.println(e.getMessage());
        }

    }
    @FXML
    void signup(ActionEvent event) throws IOException{
       String url = "jdbc:mysql://localhost:3306/university";
       String user = "root";
       String pass = "123456";
       String sql = "insert into users(user,pass) values(?,?)";
       try {
           Connection conn = DriverManager.getConnection(url,user,pass);
           PreparedStatement stm = conn.prepareStatement(sql);
           stm.setString(1,this.txtUsername.getText());
           stm.setString(2,this.txtpassword.getText());
            int r = stm.executeUpdate();
           if(r>0){

               System.out.println("signup success");

           }
          else {System.out.println("Signup failed");}
          stm.close();
       }
       catch (SQLException e){
         //print message
           System.out.println(e.getMessage());
       }
       }

}
