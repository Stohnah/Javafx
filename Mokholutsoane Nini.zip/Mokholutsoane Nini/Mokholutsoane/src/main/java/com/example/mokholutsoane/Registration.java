package com.example.mokholutsoane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Registration {

    @FXML
    private Button btnRegister;

    @FXML
    private Label lblFirstName;

    @FXML
    private Label lblLastName;

    @FXML
    private Label lblStudentID;

    @FXML
    private Label lblage;

    @FXML
    private TextField txtFirstName;

    @FXML
    private TextField txtLastName;

    @FXML
    private TextField txtStudentID;

    @FXML
    private TextField txtage;

    @FXML
    void Register(ActionEvent event) {

    }

}
